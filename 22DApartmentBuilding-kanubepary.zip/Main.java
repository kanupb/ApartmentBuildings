import java.text.DecimalFormat;

public class Main
{
	public static void main(String[]	args)	
	{
		DecimalFormat df = new DecimalFormat("$,###.00");
		System.out.println("Testing the ApartmentBuilding class.");
		System.out.println("------------------------------------");
		ApartmentBuilding	b1	= new	ApartmentBuilding("1204 PostOak Drive", 5);
		b1.setWattHours(0, 14.24);
		b1.setWattHours(1, 22.16);
		b1.setWattHours(2, 33.5);
		b1.setWattHours(3, 44.64);
		b1.setWattHours(4, 27.4);
		System.out.println(b1 +	" " +	df.format(b1.amtOwed()));
		System.out.println();
		pause();
		  
		System.out.println("Testing the ServiceArea class.");
		System.out.println("------------------------------");
		ServiceArea	area = new ServiceArea();
		area.addBuilding(b1);
		  
		Building	b2	= new	Building("2341 Oceanview");
		b2.setWattHours(44.15);
		area.addBuilding(b2);
		  
		b1	= new	ApartmentBuilding("1204 PostOak Drive", 3);
		b1.setWattHours(0, 34.34);
		b1.setWattHours(1, 12.16);
		b1.setWattHours(2, 43.52);
		area.addBuilding(b1);
		  
		b2	= new	Building("1824 Pinecrest Blvd");
		b2.setWattHours(52.6);
		area.addBuilding(b2);
		  
		  
		System.out.println(area	+ "\nTotal Amount Owed: " + df.format(area.totalSales()));
		  
		System.out.println("\nEnd of Run");
		
	 }
	 
	public static void pause()	{
		System.out.print("Press ENTER to continue...");
		(new java.util.Scanner(System.in)).nextLine();
		System.out.println();
	 }
}