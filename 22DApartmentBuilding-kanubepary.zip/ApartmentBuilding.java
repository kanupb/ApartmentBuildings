public class ApartmentBuilding extends Building
  {
    private double[] wattHrs;

    public ApartmentBuilding(String add, int num)
    {
      super(add);
      wattHrs = new double[num];
    }

    public void setWattHours(int n, double amt)
    {
      wattHrs[n] = amt;
    }
    @Override
    public double amtOwed()
    {
      double total = 0.0;
      for(int i = 0; i < wattHrs.length; i ++)
        {
          total+=wattHrs[i];
        }
      return total * RATE;
    }
  }