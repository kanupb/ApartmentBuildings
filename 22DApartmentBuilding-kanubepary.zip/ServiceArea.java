import java.util.ArrayList;

public class ServiceArea
{
  private ArrayList<Building> allBuildings;
    
  public ServiceArea() {
    allBuildings = new ArrayList<Building>();
  }
    
  public double totalSales() {
    double amt = 0.0;
    for(int i = 0; i < allBuildings.size(); i ++)
      {
        amt+= allBuildings.get(i).amtOwed();
      }
    return amt;
  }


  /******** other methods not shown **********/
    
  public void addBuilding(Building b) {
    allBuildings.add(b);
  }
    
  @Override
  public String toString() {
    String str = "";
    for (Building b : allBuildings)
      str = str + b + "\n";
    return str; 
  }
}