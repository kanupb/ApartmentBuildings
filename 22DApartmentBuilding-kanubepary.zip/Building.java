public class Building
{
  public static final double RATE = 3.25;
  private String address;
  private double wattHours;  // units of electricity used in 1 month
    
  public Building(String addr) {
    address = addr;
    wattHours = 0;
  }
    
  // returns the amount owed by this building
  public double amtOwed() {
    return wattHours * RATE;
  }
    
  /*************** other methods not shown ***************/
    
  public void setWattHours(double hours) {
    wattHours = hours;
  }
    
  public String toString() {
    return address;
  }
}